import React from 'react';

const ViewCluster = () => {
  return <div>View Your Local Cluster Page</div>;
};

export default ViewCluster;
